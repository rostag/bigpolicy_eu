module.exports = function(){
    return { appName: 'BigPolicy' };
}();

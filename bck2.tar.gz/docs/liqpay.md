
// 1 - Підключаємо як Node Module

// 2 - Повертає html:

// var html = liqpay.cnb_form({

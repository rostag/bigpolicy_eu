export class UserModel {
  id: String;
  name: String;
  email: String;
  fbId: String;
  twitterId: String;
  image: String;
  videoUrl: String;
  leaderId: String;
};

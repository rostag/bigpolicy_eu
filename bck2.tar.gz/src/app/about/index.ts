export * from './components/about.component';

